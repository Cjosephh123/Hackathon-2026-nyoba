import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import AuthLayout from '../components/AuthLayout.jsx';
import AuthInput from '../components/AuthInput.jsx';
import { LockIcon, UserIcon } from '../components/Icons.jsx';
import { login } from '../services/authService.js';

export default function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { profile } = await login({ email: email.trim(), password });
      // Members go to the library site, staff/admin go to the dashboard.
      navigate(profile.role === 'member' ? '/' : '/admin', { replace: true });
    } catch (err) {
      setError(err.message || 'Could not sign in. Check your details and try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthLayout title="Sign In" footer={<Link to="/register">Make an account</Link>}>
      <form className="auth__form" onSubmit={handleSubmit} noValidate>
        <AuthInput
          id="email"
          label="Email"
          type="email"
          autoComplete="email"
          icon={<UserIcon />}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <AuthInput
          id="password"
          label="Password"
          type="password"
          autoComplete="current-password"
          icon={<LockIcon />}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        {error && (
          <p className="auth__error" role="alert">
            {error}
          </p>
        )}

        <button className="auth__submit" type="submit" disabled={loading || !email || !password}>
          {loading ? 'Signing in…' : 'Log In'}
        </button>
      </form>
    </AuthLayout>
  );
}

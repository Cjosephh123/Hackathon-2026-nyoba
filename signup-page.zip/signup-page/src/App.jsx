import { Navigate, Route, Routes } from 'react-router-dom';
import LoginPage from './pages/LoginPage.jsx';
import RegisterPage from './pages/RegisterPage.jsx';
import PlaceholderPage from './pages/PlaceholderPage.jsx';

// Add your real pages here as the team builds them.
export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/" element={<PlaceholderPage title="Member home (coming soon)" />} />
      <Route path="/admin" element={<PlaceholderPage title="Staff dashboard (coming soon)" />} />
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}

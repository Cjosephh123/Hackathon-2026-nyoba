import bookshelf from '../assets/login-bg.jpg';
import './AuthLayout.css';

/**
 * Split-screen layout shared by the Sign In and Sign Up pages.
 * @param {string} title   Heading shown above the form
 * @param {node}   footer  Small text/link shown under the form
 */
export default function AuthLayout({ title, footer, children }) {
  return (
    <main className="auth">
      <div
        className="auth__image"
        style={{ backgroundImage: `url(${bookshelf})` }}
        role="img"
        aria-label="Shelves of novels in a bookstore"
      />

      <section className="auth__panel">
        <h1 className="auth__title">{title}</h1>
        {children}
        {footer && <p className="auth__footer">{footer}</p>}
      </section>
    </main>
  );
}
